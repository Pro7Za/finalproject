sudo apt-get update
sudo apt-get install lxde
sudo apt-get install vim
sudo apt-get install openssh-server
sudo apt install mysql-server
sudo mysql_secure_installation
sudo apt-get install iptables