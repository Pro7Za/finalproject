#!/bin/bash
chmod 700 $1