#!/bin/bash

# Проверяем, что передан аргумент (имя клиента)
if [ -z "$1" ]; then
	  echo "Использование: $0 CLIENT_NAME"
	    exit 1
fi

# Имя клиента берется из первого аргумента
CLIENT_NAME="$1"

sudo mkdir -p ~/clients/$CLIENT_NAME
sudo cp ~/clients/base.conf ~/clients/$CLIENT_NAME/client.ovpn
sudo chown -R $USER:$USER ~/clients/$CLIENT_NAME/client.ovpn
sudo chmod 766 ~/clients/$CLIENT_NAME/client.ovpn
cd ~/easy-rsa
source ./vars
#./easyrsa build-key $CLIENT_NAME
./easyrsa build-client-full  $CLIENT_NAME

# Копируем ключи и сертификаты клиента в каталог клиента
sudo cp ~/easy-rsa/pki/issued/$CLIENT_NAME.crt ~/clients/$CLIENT_NAME/
sudo cp ~/easy-rsa/pki/private/$CLIENT_NAME.key ~/clients/$CLIENT_NAME/
sudo cp ~/clients/keys/ca.crt ~/clients/$CLIENT_NAME/
sudo cp ~/clients/keys/ta.key ~/clients/$CLIENT_NAME/

sudo cat ~/clients/$CLIENT_NAME/ta.key >> ~/clients/$CLIENT_NAME/client.ovpn
sudo echo "</tls-auth>

<ca>" >> ~/clients/$CLIENT_NAME/client.ovpn
sudo cat ~/clients/$CLIENT_NAME/ca.crt  >> ~/clients/$CLIENT_NAME/client.ovpn
sudo echo "</ca>

<cert>" >> ~/clients/$CLIENT_NAME/client.ovpn
sudo cat ~/clients/$CLIENT_NAME/$CLIENT_NAME.crt >> ~/clients/$CLIENT_NAME/client.ovpn
sudo echo "</cert>

<key>" >> ~/clients/$CLIENT_NAME/client.ovpn
sudo cat ~/clients/$CLIENT_NAME/$CLIENT_NAME.key  >> ~/clients/$CLIENT_NAME/client.ovpn
sudo echo "</key>" >> ~/clients/$CLIENT_NAME/client.ovpn



