#!/bin/bash
sudo rkhunter --versioncheck

sudo rkhunter --propupd

sudo rkhunter --checkall