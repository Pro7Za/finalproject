sudo iptables -A INPUT -p tcp -m multiport --dports 22,80,443 -j ACCEPT
sudo iptables -P INPUT DROP

sudo iptables -A INPUT -p tcp --dport 53 -j ACCEPT
sudo iptables -A OUTPUT -p udp --dport 53 -j ACCEPT
sudo iptables -A OUTPUT -p icmp -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT

sudo iptables -A INPUT -i lo -j ACCEPT
sudo iptables -A OUTPUT -i lo -j ACCEPT

sudo iptables -A INPUT -m state --state ESTABLISHED -j ACCEPT

sudo service netfilter-persistent save
sudo iptables -L