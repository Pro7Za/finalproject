#!/bin/bash
date=$(date +"%Y_%m_%d")

sudo dpkg --get-selections | grep -v deinstall > backup"$date".txt
sudo tar -czf archive"$date".tar.gz /etc/
sudo mysqldump -u root mysql > /home/server/dump-"$date".sql
